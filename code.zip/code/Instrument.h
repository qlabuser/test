#pragma once
#include <iostream>

using namespace std;

namespace tickdata
{
	// struct to hold symbol and other related information
	// like market code, bbgcode, full name, qty multiplier etc.
	template <typename T>
	struct Instrument
	{		
		typedef T SymbolType;

		SymbolType m_Symbol;

		Instrument() = default;
		

		Instrument(const T & symbol) : m_Symbol(symbol)
		{

		}
		
		friend istream & operator >>(std::istream& is, Instrument<T>& instrument)
		{
			instrument.m_Symbol.ReadInstrument(is);
			return is;
		}

		friend ostream & operator <<(std::ostream& os, Instrument<T>& instrument)
		{
			instrument.m_Symbol.WriteInstrument(os);
			return os;
		}

		const SymbolType & GetSymbol() const
		{
			return m_Symbol;
		}

		bool operator <(const Instrument<T> & rhs) const
		{
			return m_Symbol < rhs.m_Symbol;
		}

		void Clear()
		{
			m_Symbol.Clear();
		}
	};

	// this is strictly a class to hold symbol only.
	template <int DEF_INSTRUMENT_SIZE = 3>
	class Symbol
	{
	protected:
		static constexpr int m_TickerLen = DEF_INSTRUMENT_SIZE + 1;
		char m_Ticker[m_TickerLen];

	public:
		Symbol()
		{
			Clear();
		}

		explicit Symbol(const char * ticker)
		{
			strncpy_s(m_Ticker, ticker, m_TickerLen);
		}

		const char * GetTicker() const
		{
			return m_Ticker;
		}
				
		void ReadInstrument(std::istream & is)
		{
			is.get(m_Ticker, m_TickerLen, ',');
		}		

		void WriteInstrument(std::ostream & os)
		{
			os << m_Ticker;
		}

		void Clear()
		{
			memset(m_Ticker, 0, m_TickerLen);
		}

		bool operator <(const Symbol & rhs) const
		{
			int result = strcmp(m_Ticker, rhs.m_Ticker);
			return result < 0 ? true : false;
		}
	};

	typedef Symbol<> DefaultSymbolType;
	typedef Instrument<DefaultSymbolType> DefaultInstrument;
}
