#pragma once

namespace tickdata
{
	typedef unsigned long long TickType;
	typedef unsigned int PriceType;
	typedef int QtyType;
	typedef unsigned long long TotalQtyType;
	typedef unsigned long long TotalValueType;
}
