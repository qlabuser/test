#pragma once
#include "Instrument.h"
#include "SpecificDataTypes.h"

namespace tickdata
{
	template <typename T = DefaultInstrument>
	class TickDataItem
	{	
	public:
		typedef T InstrmentType;

		TickDataItem() : m_tickTime{ 0 }, m_qty{ 0 }, m_price{ 0 }
		{

		}

		virtual ~TickDataItem()
		{

		}

		void Clear()
		{
			m_tickTime = m_qty = m_price = 0;
			m_Instrument.Clear();
		}

		TickType getTickTime() const
		{
			return m_tickTime;
		}

		InstrmentType getInstrument() const
		{
			return m_Instrument;
		}

		QtyType getQuantity() const
		{
			return m_qty;
		}

		PriceType getPrice() const
		{
			return m_price;
		}

		friend std::istream& operator>>(std::istream& is, TickDataItem & data)
		{
			char comma;
			
			data.Clear();

			is >> data.m_tickTime;
			is >> comma;
			is >> data.m_Instrument;
			is >> comma;
			is >> data.m_qty;
			is >> comma;
			is >> data.m_price;

			return is;
		}

	private:
		TickType m_tickTime;
		InstrmentType m_Instrument;
		QtyType m_qty;
		PriceType m_price;
	};
}
