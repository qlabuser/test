#pragma once
#include "TickDataItem.h"

namespace tickdata
{	
	class ConsolidatedTickItem
	{
	public:
		TickType m_maxTimeGap;
		TotalQtyType m_totalQty;
		TotalValueType m_totalValue;
		PriceType m_maxPrice;
		TickType m_lastTickTime;

		ConsolidatedTickItem() : m_maxTimeGap{ 0 }, m_totalQty{ 0 },
			m_totalValue{ 0 }, m_maxPrice{ 0 }, m_lastTickTime{ 0 }
		{

		}

		template <typename T>
		ConsolidatedTickItem(const T & tickData) : m_maxTimeGap{ 0 }
		{
			m_lastTickTime = tickData.getTickTime();
			m_totalQty = tickData.getQuantity();
			m_maxPrice = tickData.getPrice();
			m_totalValue = m_totalQty * m_maxPrice;
		}

		template <typename T>
		void ProcessTickData(const T& tickData)
		{
			TickType tickTimeDiff = tickData.getTickTime() - m_lastTickTime;

			if (tickTimeDiff > m_maxTimeGap)
				m_maxTimeGap = tickTimeDiff;

			m_lastTickTime = tickData.getTickTime();

			m_totalQty += tickData.getQuantity();

			if (tickData.getPrice() > m_maxPrice)
				m_maxPrice = tickData.getPrice();

			m_totalValue += (tickData.getQuantity() * tickData.getPrice());
		}

		PriceType GetWeightedAvgPrice() const
		{
			return (PriceType) ((m_totalValue / m_totalQty));
		}
	};
}