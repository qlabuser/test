#pragma once

namespace tickdata
{
	template <typename TData, typename CTData>
	class TickDataAggregator
	{
	public:
		typedef typename TData::InstrmentType TickDataInstrumentType;

		friend istream & operator >> (istream & is, TickDataAggregator& t)
		{
			if (is.peek() == std::char_traits<char>::eof())
			{
				return is;
			}

			std::string s;
			std::getline(is, s);

			if (s.empty())
			{
				return is;
			}

			std::stringstream ss(s);
			static TData data;
			ss >> data;

			/*string ticker = data.getInstrument().GetSymbol().GetTicker();
			if (ticker.empty())
			{
				cout << "empty ticker";
				return is;
			}*/

			t.ProcessTickData(data);
			return is;
		}

		friend ostream & operator <<(ostream & os, TickDataAggregator& t)
		{
			for (auto const & item : t.m_ConsolidatedTickMap)
			{
				TickDataInstrumentType instrument = item.first;
				const CTData & output = item.second;

				os << instrument << ","
					<< output.m_maxTimeGap << ","
					<< output.m_totalQty << ","
					<< output.GetWeightedAvgPrice() << ","
					<< output.m_maxPrice
					<< std::endl;
			}

			return os;
		}

		void ProcessTickData(const TData& tickData)
		{
			auto consolidatedInstTick = m_ConsolidatedTickMap.find(tickData.getInstrument());

			if (consolidatedInstTick != m_ConsolidatedTickMap.end())
			{
				consolidatedInstTick->second.ProcessTickData(tickData);
			}
			else
			{
				CTData consolidatedTick(tickData);
				m_ConsolidatedTickMap.insert(ConsolidatedTickMap::value_type(tickData.getInstrument(), consolidatedTick));
			}
		}

		const CTData GetConsolidatedData(const TickDataInstrumentType &instrument)
		{
			auto c = m_ConsolidatedTickMap.find(instrument);

			if (c != m_ConsolidatedTickMap.end())
				return c->second;

			return CTData();
		}

	private:

		typedef std::map<TickDataInstrumentType, CTData> ConsolidatedTickMap;
		ConsolidatedTickMap m_ConsolidatedTickMap;
	};

}